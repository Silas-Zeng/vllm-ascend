"""Start separate profiling only after all formal timing/audit steps pass."""

import argparse
import hashlib
import json
import subprocess
import time
from pathlib import Path


def ready(result):
    steps = result.get("steps", [])
    return (
        result.get("status") == "complete"
        and len(steps) == 30
        and sum(step["name"].endswith("_measure") for step in steps) == 18
        and sum(step["name"].endswith("_audit") for step in steps) == 12
        and all(step.get("exit_code") == 0 for step in steps)
    )


def main(args):
    state = args.root / "state" / (args.name + "_queue.json")
    info = {
        "status": "waiting_for_formal",
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "started_at": time.time(),
    }
    state.write_text(json.dumps(info, indent=2) + "\n")
    result_path = args.root / "state/context_formal_v1_20261018_result.json"
    while True:
        result = json.loads(result_path.read_text())
        if result["status"] != "running":
            break
        time.sleep(15)
    if not ready(result):
        info.update(
            status="not_launched",
            reason="formal timing/audit matrix has missing or failed steps",
            formal_status=result["status"],
        )
        state.write_text(json.dumps(info, indent=2) + "\n")
        raise RuntimeError(info["reason"])
    spec = json.loads((args.root / "state/context_formal_v1_20261018_spec.json").read_text())
    for path, expected in spec["source_sha256"].items():
        if hashlib.sha256(Path(path).read_bytes()).hexdigest() != expected:
            raise RuntimeError("frozen formal source changed: " + path)
    argv = [
        "python3",
        str(args.root / "study/deployment/make_context_job.py"),
        "--root",
        str(args.root),
        "--stage",
        str(args.stage),
        "--window-runtime",
        str(args.window_runtime),
        "--output",
        str(args.output),
        "--name",
        args.name,
        "--phase",
        "profile",
        "--reference-directory",
        str(args.root / "evidence/context_baseline_20261018/formal_v1"),
        "--launch",
    ]
    output = subprocess.check_output(argv, text=True, stderr=subprocess.STDOUT)
    info.update(status="launched", finished_at=time.time(), launcher_output=output)
    state.write_text(json.dumps(info, indent=2) + "\n")
    print(output, flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--stage", type=Path, required=True)
    parser.add_argument("--window-runtime", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--name", required=True)
    main(parser.parse_args())
