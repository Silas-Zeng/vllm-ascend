"""Read-only diagnostics and profiler annotations, enabled only in separate runs."""

import functools
import json
import os
from pathlib import Path


class StudyWorkerExtension:
    def study_inspect(self):
        return inspect_worker(self)

    def study_install_observers(self, audit_directory=None, annotate=False):
        return install_worker_observers(self, audit_directory, annotate)


def inspect_worker(worker):
    import torch

    runner = worker.model_runner
    drafter = getattr(runner, "drafter", None)
    cache = getattr(runner, "kv_cache_config", None)
    return {
        "pid": os.getpid(),
        "runner_class": type(runner).__name__,
        "target_wrapper": type(runner.model).__name__,
        "drafter_class": type(drafter).__name__ if drafter else None,
        "draft_model_class": type(drafter.model).__name__ if drafter else None,
        "window_size": getattr(drafter, "draft_window_size", None),
        "num_query_per_request": getattr(drafter, "num_query_per_req", None),
        "sample_from_anchor": getattr(drafter, "sample_from_anchor", None),
        "kernel_block_sizes": getattr(drafter, "_per_group_kernel_block_sizes", {}),
        "draft_groups": [
            {"gid": group.kv_cache_group_id, "layers": list(group.layer_names)}
            for group in getattr(drafter, "draft_attn_groups", [])
        ],
        "kv_cache_num_blocks": getattr(cache, "num_blocks", None),
        "kv_cache_group_count": len(getattr(cache, "kv_cache_groups", [])),
        "npu_allocated_bytes": torch.npu.memory_allocated(),
        "npu_reserved_bytes": torch.npu.memory_reserved(),
        "npu_peak_allocated_bytes": torch.npu.max_memory_allocated(),
    }


def _annotate_method(instance, name, label):
    import torch

    original = getattr(instance, name)

    @functools.wraps(original)
    def wrapped(*args, **kwargs):
        with torch.profiler.record_function(label):
            return original(*args, **kwargs)

    setattr(instance, name, wrapped)


def install_worker_observers(worker, audit_directory=None, annotate=False):
    import torch
    from vllm.config import get_layers_from_vllm_config
    from vllm.model_executor.layers.attention_layer_base import AttentionLayerBase

    runner = worker.model_runner
    drafter = getattr(runner, "drafter", None)
    if audit_directory:
        if drafter is None:
            raise ValueError("draft-read auditing requires a speculative model")
        from vllm_ascend.attention.attention_v1 import AscendAttentionBackend

        impl_class = AscendAttentionBackend.get_impl_cls()
        original_params = impl_class._get_fia_params
        layers = get_layers_from_vllm_config(worker.vllm_config, AttentionLayerBase)
        draft_impls = {
            id(layers[name].impl): (group.kv_cache_group_id, name)
            for group in drafter.draft_attn_groups
            for name in group.layer_names
        }
        output = Path(audit_directory) / f"worker_{os.getpid()}_draft_reads.jsonl"
        output.parent.mkdir(parents=True, exist_ok=True)

        @functools.wraps(original_params)
        def audited_params(impl, *args, **kwargs):
            result = original_params(impl, *args, **kwargs)
            if id(impl) not in draft_impls:
                return result
            gid, name = draft_impls[id(impl)]
            _, _, block_size, table, lengths = result
            metadata = args[2] if len(args) > 2 else kwargs["attn_metadata"]
            if table is None:
                return result
            if isinstance(lengths, torch.Tensor):
                lengths = lengths.detach().cpu().tolist()
            req_ids = list(runner.input_batch.req_ids)
            n = min(len(req_ids), len(lengths))
            full = drafter._per_group_block_tables[gid][:n].detach().cpu().tolist()
            read = table[:n].detach().cpu().tolist()
            positions = drafter.positions[: n * drafter.num_query_per_req].detach().cpu().tolist()
            slots = metadata.slot_mapping[: n * drafter.num_query_per_req].detach().cpu().tolist()
            record = {
                "gid": gid,
                "layer": name,
                "request_ids": req_ids[:n],
                "block_size": block_size,
                "window_config": drafter.draft_window_size,
                "kv_lengths": list(lengths[:n]),
                "read_block_tables": read,
                "full_block_tables": full,
                "query_positions": positions,
                "query_slot_mapping": slots,
                "query_per_request": drafter.num_query_per_req,
            }
            with output.open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(record) + "\n")
            return result

        impl_class._get_fia_params = audited_params
    if annotate:
        _annotate_method(worker, "execute_model", "study/worker_execute")
        target = runner.model
        target_class = type(target)
        original_call = target_class.__call__

        @functools.wraps(original_call)
        def target_call(instance, *args, **kwargs):
            if instance is target:
                with torch.profiler.record_function("study/target_forward"):
                    return original_call(instance, *args, **kwargs)
            return original_call(instance, *args, **kwargs)

        target_class.__call__ = target_call
        if drafter is not None:
            _annotate_method(drafter, "_propose", "study/draft_total")
            _annotate_method(drafter, "build_draft_attn_metadata", "study/draft_metadata")
            _annotate_method(drafter, "set_inputs_first_pass", "study/draft_inputs")
            _annotate_method(drafter, "_run_merged_draft", "study/draft_generate")
            _annotate_method(drafter.model, "forward", "study/draft_backbone")
            for method, label in [
                ("compute_logits", "study/draft_logits"),
                ("markov_embed", "study/markov_embed"),
                ("markov_bias", "study/markov_bias"),
            ]:
                _annotate_method(drafter.model, method, label)
            for group in drafter.draft_attn_groups:
                for name in group.layer_names:
                    layer = get_layers_from_vllm_config(worker.vllm_config, AttentionLayerBase)[name]
                    _annotate_method(layer.impl, "forward", "study/draft_attention")
    return {"audit_enabled": bool(audit_directory), "annotations_enabled": annotate, "pid": os.getpid()}
