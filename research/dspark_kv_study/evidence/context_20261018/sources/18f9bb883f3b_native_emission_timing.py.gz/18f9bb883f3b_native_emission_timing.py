"""Observe native LLM.generate calls without replacing request submission."""

import time


def generate_native_with_timing(llm, prompts, sampling, clock=time.perf_counter):
    engine = llm.llm_engine
    original_add = engine.add_request
    original_step = engine.step
    records = {}
    aliases = {}
    start = clock()

    def add_request(*args, **kwargs):
        request_id = args[0] if args else kwargs["request_id"]
        record = {"arrival": clock(), "first": None, "last_token": None, "finish": None, "last_count": 0, "events": []}
        records[request_id] = record
        returned = original_add(*args, **kwargs)
        aliases[request_id] = request_id
        if returned is not None:
            aliases[returned] = request_id
        return returned

    def step(*args, **kwargs):
        outputs = original_step(*args, **kwargs)
        now = clock()
        for output in outputs:
            if output.request_id not in aliases or len(output.outputs) != 1:
                raise ValueError("native observer received an unknown request or multiple sequences")
            record = records[aliases[output.request_id]]
            count = len(output.outputs[0].token_ids)
            if count < record["last_count"]:
                raise ValueError("native output is not cumulative")
            if count > record["last_count"]:
                if record["first"] is None:
                    record["first"] = now
                    record["first_count"] = count
                record["last_token"] = now
            record["last_count"] = count
            record["events"].append(
                {"time_ms": (now - start) * 1000, "output_tokens": count, "finished": output.finished}
            )
            if output.finished:
                record["finish"] = now
        return outputs

    engine.add_request, engine.step = add_request, step
    try:
        responses = llm.generate(prompts, sampling, use_tqdm=False)
    finally:
        engine.add_request, engine.step = original_add, original_step
    seconds = clock() - start
    timings = []
    for response in responses:
        record = records[aliases[response.request_id]]
        if record["first"] is None or record["finish"] is None:
            raise ValueError("native request lacks first-token or completion event")
        count = len(response.outputs[0].token_ids)
        gaps = count - record["first_count"]
        timings.append(
            {
                "ttft_ms": (record["first"] - record["arrival"]) * 1000,
                "latency_ms": (record["finish"] - record["arrival"]) * 1000,
                "tpot_ms": (record["last_token"] - record["first"]) * 1000 / gaps if gaps > 0 else None,
                "first_output_tokens": record["first_count"],
                "events": record["events"],
            }
        )
    if len(responses) != len(prompts) or len(records) != len(prompts):
        raise ValueError("native measurement request count mismatch")
    return responses, timings, seconds
