# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
from contextlib import contextmanager
from dataclasses import replace

import numpy as np
import torch
import vllm.distributed.parallel_state as _ps  # type: ignore[import-not-found]
from vllm.config import CompilationMode
from vllm.forward_context import get_forward_context


def update_num_computed_tokens_for_batch_change(
    num_computed_tokens: torch.Tensor,
    num_accepted_tokens: torch.Tensor,
    prev_positions: torch.Tensor,
    valid_sampled_token_count: torch.Tensor,
    prev_num_draft_tokens: torch.Tensor,
    cpu_num_computed_tokens: torch.Tensor,
) -> None:
    """Correct num_computed_tokens for async spec decode drift.

    Requests that had drafts: corrected = prev_gpu + valid_count.
    New requests or non-draft (e.g. prefills): use CPU value directly.
    """
    # Clamp because prev_positions can be -1 for new requests
    gather_indices = prev_positions.clamp(min=0)

    valid_counts = valid_sampled_token_count[gather_indices]
    prev_computed = num_computed_tokens[gather_indices]
    prev_drafts = prev_num_draft_tokens[gather_indices]

    participating = (prev_positions >= 0) & (prev_drafts > 0)
    corrected = prev_computed + valid_counts.int()

    n = prev_positions.shape[0]
    num_computed_tokens[:n].copy_(torch.where(participating, corrected, cpu_num_computed_tokens))
    num_accepted_tokens.copy_(torch.where(participating, valid_counts, num_accepted_tokens))


def correct_optimistic_seq_lens_cpu(
    optimistic_seq_lens_cpu_np: np.ndarray,
    prev_positions_np: np.ndarray,
    prev_num_draft_tokens_np: np.ndarray,
    valid_sampled_token_count_np: np.ndarray,
    num_reqs: int,
) -> None:
    """Correct ``optimistic_seq_lens_cpu`` for async spec decode drift.

    The scheduler optimistically advances ``num_computed_tokens_cpu`` by the
    full number of tokens scheduled in the previous step (``prev_drafts + 1``
    per spec-decode request), assuming all drafts were accepted. The actual
    number of valid sampled tokens is ``valid_count = 1 + accepted_drafts``.
    The drift, equal to the number of rejected tokens, is therefore::

        rejected = prev_drafts + 1 - valid_count

    Subtracting this from the optimistic seq_lens recovers the true seq_lens
    that ``self.seq_lens`` (GPU) carries for participating requests, without
    touching the device. New requests (``prev_positions < 0``) and prefills
    (``prev_drafts == 0``) need no correction.

    Mirrors ``update_num_computed_tokens_for_batch_change`` on the CPU side.

    All arrays are sliced to ``num_reqs``; ``optimistic_seq_lens_cpu_np`` is
    modified in place.
    """
    prev_positions = prev_positions_np[:num_reqs]
    # Clamp negative entries (new requests) to 0; the participating mask zeroes
    # out their correction so the gathered values are don't-care.
    gather_indices = np.maximum(prev_positions, 0)
    prev_drafts = prev_num_draft_tokens_np[gather_indices]
    valid_counts = valid_sampled_token_count_np[gather_indices]

    participating = (prev_positions >= 0) & (prev_drafts > 0)
    # rejected_for_participating == correction; non-participating reqs end up
    # at zero via the mask multiply.
    correction = (prev_drafts + 1 - valid_counts) * participating
    optimistic_seq_lens_cpu_np[:num_reqs] -= correction.astype(optimistic_seq_lens_cpu_np.dtype, copy=False)


def build_parallel_draft_seq_lens_cpu(
    seq_lens_cpu: torch.Tensor,
    num_reqs: int,
    query_len: int,
) -> torch.Tensor:
    """Build optimistic FIA KV lengths for one parallel-draft pass on the CPU.

    ``seq_lens_cpu`` contains the target pass's optimistic lengths (async mode
    assumes all prior drafts accepted). Add the parallel draft query block that
    will be written to cache. The post-rejection correction is deferred to the
    FIA forward entry (``pending_reject_*`` on the attention metadata), where
    the asynchronously-copied reject counts are synchronized and subtracted
    from ``seq_lens_list``; this lets the accepted-token-count D2H overlap with
    metadata build and the early draft forward instead of synchronizing in the
    proposer. The source tensor is never modified.
    """
    out = seq_lens_cpu.clone()
    out[:num_reqs].add_(query_len)
    return out


class SlidingWindowAdapter:
    """
    Sliding-window draft attention for the draft model (EAGLE3 and DFlash).
    Caps the draft model's attention to the most recent ``window_size`` (W) tokens
    by (a) cropping its block table to the window's blocks and (b) keeping every
    KV-length tensor the FIA kernel can read (notably ``_seq_lens_cpu`` for EAGLE3,
    GPU ``seq_lens`` for DFlash's ``parallel_drafting``) capped at W. Slot-mapping
    is untouched and still addresses the full, absolute KV cache via
    :attr:`full_block_table`.

    ``future_offset`` is the number of tokens beyond ``seq_lens`` (at :meth:`apply`
    time) that the window end must cover:
      * EAGLE3 passes ``num_speculative_tokens`` — its ``seq_lens`` is context-only
        and the K draft positions lie beyond it, so ``final = seq_lens + K``.
      * DFlash passes ``0`` — its ``set_inputs_first_pass`` already bakes the query
        stretch (bonus + mask) into ``seq_lens``, so ``final = seq_lens``.
    """

    def __init__(
        self,
        window_size: int,
        block_size: int,
        max_num_reqs: int,
        future_offset: int,
        device: torch.device,
    ) -> None:
        self.window_size: int = window_size
        self.block_size: int = block_size
        self.window_blocks = (window_size + block_size - 1) // block_size
        self.max_window_blocks = self.window_blocks + 1
        self._future_offset: int = future_offset
        self._block_table_clone = torch.zeros(
            (max_num_reqs, self.max_window_blocks),
            dtype=torch.int32,
            device=device,
        )

    def compute_sliding_window_block_table(
        self,
        common_attn_metadata,
        out: torch.Tensor,
    ) -> None:
        k_future = self._future_offset
        w = self.window_size
        b = self.block_size
        num_reqs = common_attn_metadata.seq_lens.shape[0]

        # Window math on the (NPU) seq_lens. Pure arithmetic -> stays on NPU.
        self.start_tokens_in_window_rounding = ((common_attn_metadata.seq_lens + k_future - w).clamp(min=0) // b) * b
        self._windowed_seq_lens = common_attn_metadata.seq_lens - self.start_tokens_in_window_rounding
        start_block_indices = self.start_tokens_in_window_rounding // b
        needed_blocks_per_req = (self._windowed_seq_lens + b - 1) // b

        full_cols = self.full_block_table.shape[1]
        # column offset grid [1, max_window_blocks]
        cols = torch.arange(self.max_window_blocks, device=self.full_block_table.device).unsqueeze(0)
        # source column per (row, col): start_block_indices[:, None] + cols
        src_cols = start_block_indices.unsqueeze(1) + cols
        # clamp to the valid full-block-table column range so gather never goes OOB
        src_cols_clamped = src_cols.clamp(max=full_cols - 1)

        gathered = torch.gather(self.full_block_table, 1, src_cols_clamped)
        needed = torch.clamp(needed_blocks_per_req, max=self.max_window_blocks).unsqueeze(1)
        # keep only columns within `needed` and within the full table; zero the rest
        valid_mask = (cols < needed) & (src_cols < full_cols)
        out[:num_reqs].copy_(gathered * valid_mask.to(gathered.dtype))

    def apply(
        self,
        common_attn_metadata,
    ) -> None:
        self.full_block_table = common_attn_metadata.block_table_tensor
        num_reqs = common_attn_metadata.seq_lens.shape[0]
        k_future = self._future_offset
        w = self.window_size
        b = self.block_size

        self.compute_sliding_window_block_table(common_attn_metadata, self._block_table_clone)
        common_attn_metadata.block_table_tensor = self._block_table_clone[:num_reqs]

        # update NPU seq_lens: reuse the value computed in compute().
        common_attn_metadata.seq_lens = self._windowed_seq_lens

        # update CPU mirrors: recompute from each one's own CPU tensor -> stays on CPU,
        # no D2H sync. numerically identical to the NPU
        for name in (
            "seq_lens_cpu",
            "_seq_lens_cpu",
            "seq_lens_cpu_upper_bound",
            "parallel_draft_seq_lens_cpu",
        ):
            src = getattr(common_attn_metadata, name, None)
            if src is not None:
                _windowed_cpu = src - ((src + k_future - w).clamp(min=0) // b) * b
                setattr(common_attn_metadata, name, _windowed_cpu)


@contextmanager
def patch_tensor_parallel_group(tp_group):
    """Temporarily swap the global TP group for draft-model spec decode.

    vllm-ascend local implementation for swapping the global TP group so the
    draft model can run with a TP degree that differs from the target model.
    """
    old_tp_group = _ps.get_tp_group()
    _ps._TP_STATE_PATCHED = True
    _ps._TP = tp_group
    try:
        yield
    finally:
        _ps._TP_STATE_PATCHED = False
        _ps._TP = old_tp_group


# TODO: Remove it when the bug of fx-graph is solved
# patch vllm_config to be in CompilationMode.NONE temporarily
@contextmanager
def _maybe_eager_context(vllm_config):
    target_compilation_config = vllm_config.compilation_config
    draft_compilation_config = replace(
        target_compilation_config,
        mode=CompilationMode.NONE,
    )
    # Model layers use these registries even when compilation is disabled.
    draft_compilation_config.static_forward_context = target_compilation_config.static_forward_context
    draft_compilation_config.static_all_moe_layers = target_compilation_config.static_all_moe_layers
    vllm_config.compilation_config = draft_compilation_config
    try:
        yield
    finally:
        vllm_config.compilation_config = target_compilation_config


# `sp` should be disabled when running MarkovHead
@contextmanager
def _disable_flash_comm_v1_context():
    forward_context = get_forward_context()
    _raw_flash_comm_v1 = forward_context.flash_comm_v1_enabled
    try:
        forward_context.flash_comm_v1_enabled = False
        yield
    finally:
        forward_context.flash_comm_v1_enabled = _raw_flash_comm_v1
